=== Jannes & Mannes AppMail ===
Contributors: jannesmannes
Tags: appmail, mail, relay
Requires at least: 3.0.1
Tested up to: 4.6.1
Stable tag: 4.6.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin let's you send email through the new Appmail.io HTTP API.

== Description ==

This plugin let's you send email through the new Appmail.io HTTP API.

== Installation ==

1. Activate the plugin
2. Copy the AppMail.io API key from your AppMail account
3. Go to the AppMail section in your dashboard, paste the API key in the form field and save the settings page
4. You are done

== Frequently Asked Questions ==

== Changelog ==

= 0.1 =
This is the first version of the plugin.